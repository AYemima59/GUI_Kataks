using System;
using System.Windows.Forms;

namespace Keuangan
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            var loginForm = new LoginRegister();
            if (loginForm.ShowDialog() == DialogResult.OK)
            {
                Application.Run(new Form1()); // Ubah dari TambahTransaksi ke Form1
            }
        }
    }
}